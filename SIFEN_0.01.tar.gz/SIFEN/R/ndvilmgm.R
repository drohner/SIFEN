ndvilmgm <-
function(fine.m,fine.n,coarse.m,coarse.p,coarse.n,lulc.m,lulc.n,growth.mp,growth.pn,tMP,tPN,numClasses,windowWidth, res.fine, res.coarse, cloudMarker = "none"){
  
  #get classes
  class.fine.m = class(fine.m)
  class.fine.n = class(fine.n)
  class.coarse.m = class(coarse.m)
  class.coarse.p = class(coarse.p)
  class.coarse.n = class(coarse.n)
  class.lulc.m = class(lulc.m)
  class.lulc.n = class(lulc.n)
  class.growth.mp = class(growth.mp)
  class.growth.pn = class(growth.pn)
  
  #convert to matrices
  fine.m.mat = raster::as.matrix(fine.m)
  fine.n.mat = raster::as.matrix(fine.n)
  coarse.m.mat = raster::as.matrix(coarse.m)
  coarse.p.mat = raster::as.matrix(coarse.p)
  coarse.n.mat = raster::as.matrix(coarse.n)
  lulc.m.mat = raster::as.matrix(lulc.m)
  lulc.n.mat = raster::as.matrix(lulc.n)
  growth.mp.mat = raster::as.matrix(growth.mp)
  growth.pn.mat = raster::as.matrix(growth.pn)
  
  #get dimension
  fine.m.mat.dim = dim(fine.m.mat)
  fine.n.mat.dim = dim(fine.n.mat)
  coarse.m.mat.dim = dim(coarse.n.mat)
  coarse.p.mat.dim = dim(coarse.p.mat)
  coarse.n.mat.dim = dim(coarse.n.mat)
  lulc.m.mat.dim = dim(lulc.m.mat)
  lulc.n.mat.dim = dim(lulc.n.mat)
  growth.mp.mat.dim = dim(growth.mp.mat)
  growth.pn.mat.dim = dim(growth.pn.mat)
  
  #check input: class
  if(class.fine.m != "RasterLayer"){stop("fine.m has to be of the class RasterLayer")}
  if(class.fine.n != "RasterLayer"){stop("fine.n has to be of the class RasterLayer")}
  if(class.coarse.m != "RasterLayer"){stop("coarse.m has to be of the class RasterLayer")}
  if(class.coarse.p != "RasterLayer"){stop("coarse.p has to be of the class RasterLayer")}
  if(class.coarse.n != "RasterLayer"){stop("coarse.n has to be of the class RasterLayer")}
  if(class.lulc.m != "RasterLayer"){stop("lulc.m has to be of the class RasterLayer")}
  if(class.lulc.n != "RasterLayer"){stop("lulc.n has to be of the class RasterLayer")}
  if(class.growth.mp != "RasterLayer"){stop("growth.mp has to be of the class RasterLayer")}
  if(class.growth.pn != "RasterLayer"){stop("growth.mp has to be of the class RasterLayer")}
  
  #check input: values
  if(any(fine.m.mat < -1 && fine.m.mat != cloudMarker) || any(fine.m.mat > 1 && fine.m.mat != cloudMarker)){stop("All values (expect the cloud-marker) have to be between -1 and 1 (error in fine.m)")}
  if(any(fine.n.mat < -1 && fine.n.mat != cloudMarker) || any(fine.n.mat > 1 && fine.n.mat != cloudMarker)){stop("All values (expect the cloud-marker) have to be between -1 and 1 (error in fine.n)")}
  if(any(coarse.m.mat < -1 && coarse.m.mat != cloudMarker) || any(coarse.m.mat > 1 && coarse.m.mat != cloudMarker)){stop("All values (expect the cloud-marker) have to be between -1 and 1 (error in coarse.m)")}
  if(any(coarse.p.mat < -1 && coarse.p.mat != cloudMarker) || any(coarse.p.mat > 1 && coarse.p.mat != cloudMarker)){stop("All values (expect the cloud-marker) have to be between -1 and 1 (error in coarse.p)")}
  if(any(coarse.n.mat < -1 && coarse.n.mat != cloudMarker) || any(coarse.n.mat > 1 && coarse.n.mat != cloudMarker)){stop("All values (expect the cloud-marker) have to be between -1 and 1 (error in coarse.n)")}
  
  if(!all(lulc.m.mat %in% c(1:numClasses) ) || any(lulc.m.mat %% 1 != 0)){stop("The landcover and landuse has to be identified by integers from 1 to numClasses (error in lulc.m)")}
  if(!all(lulc.n.mat %in% c(1:numClasses) ) || any(lulc.n.mat %% 1 != 0)){stop("The landcover and landuse has to be identified by integers from 1 to numClasses (error in lulc.n)")}
  
  if(!is.numeric(growth.mp.mat)){stop("growth.mp has to be numeric")}
  if(!is.numeric(growth.pn.mat)){stop("growth.pn has to be numeric")}
  
  if(!is.numeric(numClasses) || numClasses < 1 || numClasses %% 1 != 0){ stop("The number of classes numClasses has to be an integer greater than 0")}
  if(!is.numeric(windowWidth) || windowWidth%%2 == 0 || windowWidth < 3){ stop("The windowWidth has to be an uneven integer greater than 1")}
  if(windowWidth < sqrt(numClasses)){ stop("The windowWidth hat to be greater than the square root of the number of class numClass")}
  if(!is.numeric(res.fine) || res.fine < 0){ stop("res.fine has to be a number greater than 0")}
  if(!is.numeric(res.coarse) ||res.coarse < 0){ stop("res.coarse has to be a number greater than 0")}
  if(res.coarse < res.fine){ stop("The coarse resolution is smaller than the fine resoultion")}
  if(!is.numeric(tMP) || tMP < 0){ stop("tMP has to be a number greater than 0")}
  if(!is.numeric(tPN) || tPN < 0){ stop("tPN has to be a number greater than 0")}
  if((!is.numeric(cloudMarker) || cloudMarker %% 1 != 0) && cloudMarker != "none"){ stop("cloudMarker has to be an integer")}
  
  
  #check input: dimension
  if(!all(coarse.m.mat.dim == coarse.n.mat.dim) || !all(coarse.m.mat.dim == coarse.p.mat.dim) || !all(coarse.n.mat.dim == coarse.p.mat.dim)){stop("All coarse input must not differ in dimension")}
  if(!all(growth.mp.mat.dim == coarse.m.mat.dim) || !all(growth.pn.mat.dim == coarse.n.mat.dim) || !all(growth.mp.mat.dim == growth.pn.mat.dim)){stop("All RasterLayer containing the coarse growth rate must not differ in dimension to the others or the corresponding data ")}
  if(!all(fine.m.mat.dim == fine.n.mat.dim)){stop("fine.m and fine.n have different dimensions")}
  if(!all(lulc.n.mat.dim == lulc.m.mat.dim)){stop("lulc.m and lulc.n have different dimensions")}
  if(!all(fine.m.mat.dim == lulc.n.mat.dim)){stop("The spatial fine resoulion ndvi data and the land use and land cover data must not differ in dimension")}
  if(any(fine.n.mat.dim < ceiling(coarse.m.mat.dim * res.fine / res.coarse))){ stop("The dimension of the spatial fine resolution data is not big enough")}
  if(windowWidth >= coarse.n.mat.dim[1] || windowWidth >= coarse.n.mat.dim[2]){ stop("The window width is to big to calculate a  result (see section value)")}
  
  #call C++ to generate image
  if(cloudMarker == "none"){
    print("NDVI-LMGM called with no cloud-marker.")
    tmp = .Call("SIFEN_wrapper_ndvi_lmgm", coarse.m.mat,coarse.p.mat,coarse.n.mat,fine.m.mat,fine.n.mat,lulc.m.mat,lulc.n.mat,growth.mp.mat,growth.pn.mat,numClasses,windowWidth,res.fine,res.coarse,tMP,tPN)
  }
  else{
    cat("NDVI-LMGM called with ", cloudMarker, " as the cloud-marker. \n")
    tmp = .Call("SIFEN_wrapper_ndvi_lmgm_cm", coarse.m.mat,coarse.p.mat,coarse.n.mat,fine.m.mat,fine.n.mat,lulc.m.mat,lulc.n.mat,growth.mp.mat,growth.pn.mat,numClasses,windowWidth,res.fine,res.coarse,tMP,tPN, cloudMarker)
  }

  result = raster::raster(tmp)
  
  cat("Computation finished. The resulting image has", ncol(tmp), "columns and", nrow(tmp), "rows. \n")

  return (result)
}
