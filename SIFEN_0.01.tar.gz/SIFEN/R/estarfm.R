estarfm <-
function(fine.m, fine.n, coarse.m, coarse.p, coarse.n, numClasses, windowWidth, res.fine, res.coarse, rsquaredthreshold, cores, cloudMarker = "none"){
  class.fine.n = class(fine.n)
  class.fine.m = class(fine.m)
  class.coarse.m = class(coarse.m)
  class.coarse.p = class(coarse.p)
  class.coarse.n = class(coarse.n)
  fine.n.arr = raster::as.array(fine.n)
  fine.m.arr = raster::as.array(fine.m)
  coarse.n.arr = raster::as.array(coarse.n)
  coarse.m.arr = raster::as.array(coarse.m)
  coarse.p.arr = raster::as.array(coarse.p)
  fine.m.arr.dim = dim(fine.m.arr)
  fine.n.arr.dim = dim(fine.n.arr)
  coarse.m.arr.dim = dim(coarse.m.arr)
  coarse.p.arr.dim = dim(coarse.p.arr)
  coarse.n.arr.dim = dim(coarse.n.arr)
  
  #check input: class
  if(class.fine.n != "RasterBrick" && class.fine.n != "RasterStack"){ stop("fine.n has to be of the class RasterBrick or RasterStack")}
  if(class.fine.m != "RasterBrick" && class.fine.m != "RasterStack"){ stop("fine.m has to be of the class RasterBrick or RasterStack")}
  if(class.coarse.m != "RasterBrick" && class.coarse.m != "RasterStack"){ stop("coarse.m has to be of the class RasterBrick or RasterStack")}
  if(class.coarse.p != "RasterBrick" && class.coarse.p != "RasterStack"){ stop("coarse.p has to be of the class RasterBrick or RasterStack")}
  if(class.coarse.n != "RasterBrick" && class.coarse.n != "RasterStack"){ stop("coarse.n has to be of the class RasterBrick or RasterStack")}
  
  #check input: values
  if(any(fine.n.arr < 0 && fine.n.arr != cloudMarker) || any(fine.n.arr %% 1 != 0)){ stop("All values (expect the cloud-marker) have to be positive integers or equal to 0 (error in fine.n)")}
  if(any(fine.m.arr < 0 && fine.m.arr != cloudMarker) || any(fine.m.arr %% 1 != 0)){ stop("All values (expect the cloud-marker) have to be positive integers or equal to 0 (error in fine.m)")}
  if(any(coarse.n.arr < 0 && coarse.n.arr != cloudMarker) || any(coarse.n.arr %% 1 != 0)){ stop("All values (expect the cloud-marker) have to be positive integers or equal to 0 (error in coarse.n)")}
  if(any(coarse.m.arr < 0 && coarse.m.arr != cloudMarker) || any(coarse.m.arr %% 1 != 0)){ stop("All values (expect the cloud-marker) have to be positive integers or equal to 0 (error in coarse.m)")}
  if(any(coarse.p.arr < 0 && coarse.p.arr != cloudMarker) || any(coarse.p.arr %% 1 != 0)){ stop("All values (expect the cloud-marker) have to be positive integers or equal to 0 (error in coarse.p)")}
  if(!is.numeric(numClasses) || numClasses < 1 || numClasses %% 1 != 0){ stop("The number of classes numClasses has to be an integer greater than 0")}
  if(!is.numeric(windowWidth) || windowWidth%%2 == 0 || windowWidth < 3){ stop("The windowWidth has to be an uneven integer greater than 1")}
  if(!is.numeric(res.fine) || res.fine < 0){ stop("res.fine has to be a number greater than 0")}
  if(!is.numeric(res.coarse) ||res.coarse < 0){ stop("res.coarse has to be a number greater than 0")}
  if(res.coarse < res.fine){ stop("The coarse resolution is smaller than the fine resoultion")}
  if(rsquaredthreshold > 1 || rsquaredthreshold < 0 || !is.numeric(rsquaredthreshold)){ stop("rsquaredthreshold has to be a number between 0 and 1")}
  if(!is.numeric(cores) || cores < 1 || cores %% 1 != 0){stop("The number of CPU-cores cores to use has to be an integer greater than 0")}
  if((!is.numeric(cloudMarker) || cloudMarker %% 1 != 0) && cloudMarker != "none"){ stop("cloudMarker has to be an integer")}
  
  #check input: dimension
  if(!all(fine.m.arr.dim == fine.n.arr.dim) ||
     !all(fine.n.arr.dim == coarse.m.arr.dim) ||
     !all(coarse.m.arr.dim == coarse.p.arr.dim) ||
     !all(coarse.p.arr.dim == coarse.n.arr.dim)
     ){stop("The input raster data must not differ in dimension")}
  if(windowWidth >= fine.m.arr.dim[1] || windowWidth >= fine.m.arr.dim[2]){ stop("The window width is to big to calculate a  result (see section value)")}
  
  #call C++ to generate image
  if(cloudMarker == "none"){
    print("ESTARFM called with no cloud-marker.")
    tmp = .Call("SIFEN_wrapper_estarfm", fine.m.arr, fine.n.arr, coarse.m.arr, coarse.p.arr, coarse.n.arr, windowWidth, numClasses, res.fine, res.coarse, rsquaredthreshold, cores)
  }
  else{
    cat("ESTARFM called with ", cloudMarker, " as the cloud-marker. \n")
    tmp = .Call("SIFEN_wrapper_estarfmCM", fine.m.arr, fine.n.arr, coarse.m.arr, coarse.p.arr, coarse.n.arr, windowWidth, numClasses, res.fine, res.coarse, rsquaredthreshold, cores, cloudMarker)
  }
  #build RasterStack or RasterBrick
  dimension = dim(fine.n.arr) 
  if(class.coarse.p == "RasterBrick"){
    result = raster::brick(array(tmp, dim = c(dimension[1]- windowWidth +1, dimension[2] - windowWidth + 1, dimension[3]))) 
  }
  else{
    result = raster::stack(raster::brick(array(tmp, dim = c(dimension[1]- windowWidth +1, dimension[2] - windowWidth +1, dimension[3]))))
  }
  
  cat("Computation finished. The resulting image has", dim(result)[2], "columns and", dim(result)[1], "rows. \n")
  
  return (result)
}
