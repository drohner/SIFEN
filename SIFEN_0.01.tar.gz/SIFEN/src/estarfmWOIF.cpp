#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <numeric>
#include <cmath>
#include <map>
#include <thread>
#include <mutex>
#include "lib/Eigen/Dense"


//define alias
typedef Eigen::MatrixXi Band;
typedef std::vector<Band> Image;
typedef Eigen::Vector2i Pixel;
typedef std::vector<Pixel> Pixels;
typedef std::vector<double> Deviations;

/*
define general parameter
	_fineM: spatial fine-resolution image at point of time m (before p)
	_fineN: spatial fine-resolution image at point of time n (after p)
	_coarseM: spatial coarse-resolution image at point of time m (before p)
	_coarseN: spatial coarse-resolution image at point of time n (after p)
	_coarseP: spatial coarse-resolution image at point of time p
	_windowWidthHalf: half of the given windowwidth: (w-1)/2
	_estimatedClasses: number of estimated landuse/ and andcover classes
	_countBands: number of bands of a single image
	_ratioCoarseToFine: resolution coarse divided by resolution fine (spatial)
	_ratioCoarseToFineInt: the integer value of the given ratio
	_centralCoarsePixels: the coressponding coarse pixel for fine pixels
	_correlationCoefficientThreshold: the threshold when the linear model is not significant
	_imageHeight
	_imageWidth	
*/

struct ProgramParameters {
	const Image _fineM;
	const Image _fineN;
	const Image _coarseM;
	const Image _coarseN;
	const Image _coarseP;
	const unsigned int _windowWidthHalf;
	const unsigned int _estimatedClasses;
	const unsigned int _countBands;
	const double _ratioCoarseToFine;
	const unsigned int _ratioCoarseToFineInt;
	const std::vector<std::vector<Pixel>> _centralCoarsePixels;
	const double _correlationCoefficientThreshold;
	const unsigned int _imageHeight;
	const unsigned int _imageWidth;
};


// number of cores for parallelization
unsigned int __countCores;

//compute mean for different input
inline double computeMean(const std::vector<int> &v) {
	return std::accumulate(v.begin(), v.end(), 0.0) / v.size();
}

inline Eigen::Vector2d computeMean(const std::vector<Pixel> &v) {
	return{
		std::accumulate(v.begin(), v.end(), 0.0, [](const double r, const Pixel &c) {return r + c[0]; }) / v.size(),
		std::accumulate(v.begin(), v.end(), 0.0, [](const double r, const Pixel &c) {return r + c[1]; }) / v.size()
	};
}

double computeMean(const Eigen::MatrixXi &b) {
	const int height = b.rows();
	const int width = b.cols();

	int sum = 0;
	for (int y = 0; y < height; ++y)
		for (int x = 0; x < width; ++x)
			sum += b(y, x);

	return (double)sum / (height * width);
}

//compute standard deviation
double getStandardDeviation(const Eigen::MatrixXi &b) {
	const int height = b.rows();
	const int width = b.cols();

	const double mean = computeMean(b);

	double squaredSumDifference = 0.0;
	for (int y = 0; y < height; ++y)
		for (int x = 0; x < width; ++x)
			squaredSumDifference += std::pow(mean - b(y, x), 2);

	return std::sqrt(squaredSumDifference / (height * width));
}

//compute the half window width based on an uneven input
int getWindowWidthHalf(const int windowWidth) {
	return (windowWidth - 1) / 2;
}


//compute the correlation coefficient for different input
double computeCorrelationCoefficient(const std::vector<int> &a, const std::vector<int> &b) {
	const unsigned int cnt = a.size();

	const double aMean = computeMean(a);
	const double bMean = computeMean(b);

	double nominator(0.0), denominator1(0.0), denominator2(0.0);
	for (unsigned int i = 0; i < cnt; ++i) {
		nominator += (a[i] - aMean) * (b[i] - bMean);
		denominator1 += std::pow((a[i] - aMean), 2);
		denominator2 += std::pow((b[i] - bMean), 2);
	}

	return nominator / std::sqrt(denominator1 * denominator2);
}

double computeCorrelationCoefficient(const std::vector<Pixel> &v) {
	const unsigned int cnt = v.size();

	const auto mean = computeMean(v);

	double nominator(0.0), denominator1(0.0), denominator2(0.0);
	for (unsigned int i = 0; i < cnt; ++i) {
		nominator += (v[i][0] - mean[0]) * (v[i][1] - mean[1]);
		denominator1 += (v[i][0] - mean[0]) * (v[i][0] - mean[0]);
		denominator2 += (v[i][1] - mean[1]) * (v[i][1] - mean[1]);
	}

	return nominator / std::sqrt(denominator1 * denominator2);
}

//compute the slope of a linear regression model
double computeSlopeRegressionLine(const Pixels &v) {
	const unsigned int cnt = v.size();
	const auto mean = computeMean(v);

	double denominator(0.0), nominator(0.0);
	for (unsigned int i = 0; i < cnt; ++i) {
		nominator += (v[i][0] - mean[0]) * (v[i][1] - mean[1]);
		denominator += (v[i][0] - mean[0]) * (v[i][0] - mean[0]);
	}

	return nominator / denominator;
}

/*
	Calculate the similiar pixels for a given image based on the threshold method presented in the coressponding paper
*/

Pixels findSimilarPixels(const Image &img, const int imgHeight, const int imgWidth, const int estimatedClasses, const Pixel &windowCenter, const int windowWidthHalf, const Deviations &deviations) {
	Pixels res;
	res.reserve(4 * windowWidthHalf * windowWidthHalf + 4 * windowWidthHalf + 1);
	const unsigned int cntBand = img.size();

	// copy center pixel values from each band to reduce lookup 
	std::vector<int> centerValue(cntBand);
	for (unsigned int i = 0; i < cntBand; ++i)
		centerValue[i] = img[i](windowCenter[1], windowCenter[0]);

	// precompute the thresholds for each band
	std::vector<double> bandThresholds(cntBand);
	for (unsigned int i = 0; i < cntBand; ++i)
		bandThresholds[i] = 2.0 / estimatedClasses * deviations[i];

	// check all pixels in the current window on similarity to center pixel
	bool similar;
	const int minY = std::max(windowCenter[1] - windowWidthHalf, 0);
	const int maxY = std::min(windowCenter[1] + windowWidthHalf, imgHeight - 1);
	const int minX = std::max(windowCenter[0] - windowWidthHalf, 0);
	const int maxX = std::min(windowCenter[0] + windowWidthHalf, imgWidth - 1);
	for (int currentY = minY; currentY <= maxY; ++currentY)
		for (int currentX = minX; currentX <= maxX; ++currentX, similar = true) {
			// pixel similarity : the similarity threshold has to be true for all bands
			for (unsigned int i = 0; i < cntBand; ++i)
				if (std::abs(img[i](currentY, currentX) - centerValue[i]) > bandThresholds[i]) {
					similar = false;
					break;
				}

			// if the pixel is similar we add it to our found ones
			if (similar)
				res.push_back({ currentX, currentY });
		}
	
	return res;
}

/**
 * compute the weights for a given set of similar pixels.
 */
std::vector<double> computeWeight(const ProgramParameters &imageInformations, const Pixels &similarFinePixels, const Pixel &windowCenter) {
	std::vector<double> res;
	res.reserve(similarFinePixels.size());

	const unsigned int cntBand = imageInformations._fineM.size();

	std::vector<int> Fi(2 * cntBand);
	std::vector<int> Ci(2 * cntBand);
	const unsigned int max = similarFinePixels.size();
	double Ri(0.0), di, Di;
	for (const auto &c : similarFinePixels) {
		// compute vector F_i and C_i (fine and coarse values, combined from each band)
		for (unsigned int i = 0; i < cntBand; ++i) {
			Fi[i] = imageInformations._fineM[i](c[1], c[0]);
			Fi[cntBand + i] = imageInformations._fineN[i](c[1], c[0]);
			Ci[i] = imageInformations._coarseM[i](c[1], c[0]);
			Ci[cntBand + i] = imageInformations._coarseN[i](c[1], c[0]);
		}

		// compute the correlation coefficient for the vectors
		if(cntBand > 1){
			 Ri = computeCorrelationCoefficient(Fi, Ci);
		}
		// compute geographic distance
		di = 1 + std::sqrt((windowCenter[0] - c[0])*(windowCenter[0] - c[0]) + (windowCenter[1] - c[1])*(windowCenter[1] - c[1])) / imageInformations._windowWidthHalf;

		// absolute pixel weight
		Di = (1 - Ri) * di;

		res.push_back(1.0 / Di);
	}

	// set the weights in relation to all others
	const double weightSum = std::accumulate(res.begin(), res.end(), 0.0); // sum over 1.0/Di
	std::for_each(res.begin(), res.end(), [weightSum](double &Di) { Di /= weightSum; });

	return res;
}


// compute the coarse pixel center for a given pixel based on the ratio between the fine and coarse resolution
inline Pixel computeCentralCoarsePixel(const int fineX, const int fineY, const double ratioCoarseToFine) {
	return{ std::round(std::floor((double)fineX / ratioCoarseToFine) * ratioCoarseToFine + ratioCoarseToFine / 2.0), std::round(std::floor((double)fineY / ratioCoarseToFine) * ratioCoarseToFine + ratioCoarseToFine / 2.0) };
}

/**
 * //TODO function description
 * 
 */
std::vector<double> computeConversionCoefficient(const ProgramParameters &imageInformations, const Pixels &similarPixels, const Image &similarPixelImageFine, const Deviations &deviationsFine, const unsigned int band) {
	const int imageWidth = imageInformations._imageWidth;
	std::vector<double> res;
	res.reserve(similarPixels.size());

	double slope;
	const auto &coarseM = imageInformations._coarseM[band];
	const auto &coarseN = imageInformations._coarseN[band];
	const auto &fineM = imageInformations._fineM[band];
	const auto &fineN = imageInformations._fineN[band];

	std::map<long, double> conversionCoefficientLookuptable;
	std::map<long, double>::iterator conversionCoefficientLookuptableIt;
	for (const auto &currSimPixel : similarPixels) { // for each similar pixel
		// find central coarse pixel
		const Pixel &centralCoarse = imageInformations._centralCoarsePixels[currSimPixel[1]][currSimPixel[0]];
		const long hash = centralCoarse[1] * imageWidth + centralCoarse[0];

		// only compute the following if not done before for the central coarse pixel
		if ((conversionCoefficientLookuptableIt = conversionCoefficientLookuptable.find(hash)) == conversionCoefficientLookuptable.end()) {
			// find similar pixels in fine resolution image, centered around the real-coarse-pixel with window width equal to the ratio from fine to coarse image size
			const auto &similarPixelsAroundCoarsepixel = findSimilarPixels(similarPixelImageFine, imageInformations._imageHeight, imageInformations._imageWidth, imageInformations._estimatedClasses, centralCoarse, imageInformations._windowWidthHalf, deviationsFine);
			const unsigned int cntsimilarPixelsAroundCoarsepixel = similarPixelsAroundCoarsepixel.size();

			// determine image value pairs in both times M and N in one single set : <coarse, fine>
			Pixels pairsCoarseFine;
			pairsCoarseFine.reserve(2 * cntsimilarPixelsAroundCoarsepixel);
			for (const auto &c : similarPixelsAroundCoarsepixel) { // for all similar pixels resulting from the coarse image search
				pairsCoarseFine.push_back({ coarseM(c[1], c[0]), fineM(c[1], c[0]) });
				pairsCoarseFine.push_back({ coarseN(c[1], c[0]), fineN(c[1], c[0]) });
			}

			// if the correlation coefficient for the dataset is to insignificant we just assume a slope of 1
			if (std::pow(computeCorrelationCoefficient(pairsCoarseFine), 2) < imageInformations._correlationCoefficientThreshold)
				slope = 1.0;
			else // compute a line l with a linear regression model (here: minimum squared error) over the data pairs -> store the slope s of l for the current similar pixel
				slope = computeSlopeRegressionLine(pairsCoarseFine);

			conversionCoefficientLookuptableIt = conversionCoefficientLookuptable.insert({ hash, slope }).first;
		}

		res.push_back((*conversionCoefficientLookuptableIt).second);
	}

	return res;
}

double computeImagePrediction(const Band &imageFine, const Pixels &imageFineSimilarPixels, const std::vector<double> &imageFineWeights, const std::vector<double> &imageFineConversionCoefficients, const Band &imageCoarse, const Band &imageCoarseTarget, const Pixel windowCenter) {
	const unsigned int cnt = imageFineSimilarPixels.size();

	double acc = 0.0;
	for (unsigned int i = 0; i < cnt; ++i) {
		acc += imageFineWeights[i] * imageFineConversionCoefficients[i] * (imageCoarseTarget(imageFineSimilarPixels[i][1], imageFineSimilarPixels[i][0]) - imageCoarse(imageFineSimilarPixels[i][1], imageFineSimilarPixels[i][0]));
	}

	return acc + imageFine(windowCenter[1], windowCenter[0]);
}

double computeTemporalWeightNominator(const Band &imageCoarse, const Band &imageCoarseTarget, const Pixel &windowCenter, const unsigned int windowWidthHalf) {
	double sum1(0), sum2(0);
	for (unsigned int currY = windowCenter[1] - windowWidthHalf; currY < windowCenter[1] + windowWidthHalf; ++currY)
		for (unsigned int currX = windowCenter[0] - windowWidthHalf; currX < windowCenter[0] + windowWidthHalf; ++currX) {
			sum1 += imageCoarse(currY, currX);
			sum2 += imageCoarseTarget(currY, currX);
		}

	return 1.0 / std::abs(sum1 - sum2);
}

/**
 * This will perform a single program step for one central pixel.
 * It computes the necessary values (similar pixels, weights, conversion coefficient) for both, timestep M and timestep N, and finally compute the resulting reflectance for the central pixel.
 */
double computeCentralPixelReflectance(const ProgramParameters &imageInformations, const Pixel &windowCenter, const Deviations &deviationsFineM, const Deviations &deviationsFineN, const int band) {
	// timestep M
	const auto &similarPixelsFineM = findSimilarPixels(imageInformations._fineM, imageInformations._imageHeight, imageInformations._imageWidth, imageInformations._estimatedClasses, windowCenter, imageInformations._windowWidthHalf, deviationsFineM);
	const auto &similarPixelsFineMWeights = computeWeight(imageInformations, similarPixelsFineM, windowCenter);
	const auto &similarPixelsFineMConversionCoefficients = computeConversionCoefficient(imageInformations, similarPixelsFineM, imageInformations._fineM, deviationsFineM, band);
	const double similarPixelsFineMPrediction = computeImagePrediction(imageInformations._fineM[band], similarPixelsFineM, similarPixelsFineMWeights, similarPixelsFineMConversionCoefficients, imageInformations._coarseM[band], imageInformations._coarseP[band], windowCenter);
	double TMNominator = computeTemporalWeightNominator(imageInformations._coarseM[band], imageInformations._coarseP[band], windowCenter, imageInformations._windowWidthHalf);

	// timestep N
	const auto &similarPixelsFineN = findSimilarPixels(imageInformations._fineN, imageInformations._imageHeight, imageInformations._imageWidth, imageInformations._estimatedClasses, windowCenter, imageInformations._windowWidthHalf, deviationsFineN);
	const auto &similarPixelsFineNWeights = computeWeight(imageInformations, similarPixelsFineN, windowCenter);
	const auto &similarPixelsFineNConversionCoefficients = computeConversionCoefficient(imageInformations, similarPixelsFineN, imageInformations._fineN, deviationsFineN, band);
	const double similarPixelsFineNPrediction = computeImagePrediction(imageInformations._fineN[band], similarPixelsFineN, similarPixelsFineNWeights, similarPixelsFineNConversionCoefficients, imageInformations._coarseN[band], imageInformations._coarseP[band], windowCenter);
	double TNNominator = computeTemporalWeightNominator(imageInformations._coarseN[band], imageInformations._coarseP[band], windowCenter, imageInformations._windowWidthHalf);

	//check for imposibble values
	if (std::isinf(TMNominator))
		TMNominator = 1 - TNNominator;
	else if (std::isinf(TNNominator))
		TNNominator = 1 - TMNominator;

	// compute the real resulting temporal weights for each timestep (now that we have acquired all necessary informations)
	const double TM = TMNominator / (TMNominator + TNNominator);
	const double TN = TNNominator / (TMNominator + TNNominator);

	// return the target central pixel reflectance value
	return TM * similarPixelsFineMPrediction + TN * similarPixelsFineNPrediction;
}

/**
 * Main loop, resulting in a returned band.
 * All given images are required to be of the same size (in width and height).
 */
Band programLoop(const Image &fineM, const Image &fineN, const Image &coarseM, const Image &coarseN, const Image &coarseP, const unsigned int windowWidth, const unsigned int estimatedClasses, const double ratioCoarseToFine, const double correlationCoefficientThreshold, const int band) {
	const int imageWidth = fineM[0].cols();
	const int imageHeight = fineM[0].rows();

	// compute the standard deviations for each required image and each band therein
	Deviations deviationsFineM;
	for (const auto &c : fineM)
		deviationsFineM.push_back(getStandardDeviation(c));
	Deviations deviationsFineN;
	for (const auto &c : fineN)
		deviationsFineN.push_back(getStandardDeviation(c));

	// compute the corresponding coarse center pixels for each fine pixel
	std::vector<std::vector<Pixel>> correspondingCoarseCenterPixels(imageHeight, std::vector<Pixel>(imageWidth));
	for (int y = 0; y < imageHeight; ++y)
		for (int x = 0; x < imageWidth; ++x)
			correspondingCoarseCenterPixels[y][x] = computeCentralCoarsePixel(x, y, ratioCoarseToFine);

	// collect all static data
	const unsigned int windowWidthHalf = getWindowWidthHalf(windowWidth);
	const ProgramParameters imageInformations{
		fineM, fineN, coarseM, coarseN, coarseP,
		windowWidthHalf, estimatedClasses, fineM.size(),
		ratioCoarseToFine, (unsigned int)std::round(imageInformations._ratioCoarseToFine),
		correspondingCoarseCenterPixels, correlationCoefficientThreshold,
		imageHeight, imageWidth
	};

	// create threads and process all pixels
	Band res(imageHeight, imageWidth);
	res.setZero();
	std::vector<std::thread> threads(__countCores);
	const double threadWorkloadY = (double)((imageHeight - windowWidthHalf) - (0 + windowWidthHalf)) / __countCores;
	for (unsigned int i = 0; i < __countCores; ++i) {
		threads[i] = std::thread([&, i]() {
			for (unsigned int windowCenterY = windowWidthHalf + (int)(i*threadWorkloadY); windowCenterY < windowWidthHalf + (int)((i + 1)*threadWorkloadY); ++windowCenterY)
				for (unsigned int windowCenterX = 0 + windowWidthHalf; windowCenterX < imageWidth - windowWidthHalf; ++windowCenterX)
					res(windowCenterY, windowCenterX) = (int)std::round(computeCentralPixelReflectance(imageInformations, { windowCenterX, windowCenterY }, deviationsFineM, deviationsFineN, band));
		});
	}
	
	for (unsigned int i = 0; i < __countCores; ++i)
		threads[i].join();

	return res;
}

/**
 * Main loop, resulting in a return for all bands.
 */
Image programLoop(const Image &fineM, const Image &fineN, const Image &coarseM, const Image &coarseN, const Image &coarseP, const unsigned int windowWidth, const unsigned int estimatedClasses, const double ratioCoarseToFine, const double correlationCoefficientThreshold) {
	const unsigned int cntBands = fineM.size();
	Image res(cntBands);

	for (unsigned int currBand = 0; currBand < cntBands; ++currBand)
		res[currBand] = programLoop(fineM, fineN, coarseM, coarseN, coarseP, windowWidth, estimatedClasses, ratioCoarseToFine, correlationCoefficientThreshold, currBand);

	return res;
}


// remove border around the resulting pixels (created by shrinking the image by the windowwidth)
Band removeZeroBorder(const Band &b, const unsigned int windowWidthHalf) {
	return b.block(windowWidthHalf, windowWidthHalf, b.rows() - 2 * windowWidthHalf, b.cols() - 2 * windowWidthHalf);
}
Image removeZeroBorder(const Image &i, const unsigned int windowWidthHalf) {
	Image res;
	res.reserve(i.size());
	for (const auto &c : i)
		res.push_back(removeZeroBorder(c, windowWidthHalf));
	return res;
}





/*
	The call from R
	The data is obtained and afterwards written into Eigen-Matricies for a fast calculation.
	Theses are handed over to the main program loop
*/
#include <RcppArmadillo.h>
// [[Rcpp::export]]
Rcpp::NumericVector wrapper_estarfm(SEXP fineM, SEXP fineN, SEXP coarseM, SEXP coarseP, SEXP coarseN, SEXP winWidth, SEXP estClasses, SEXP fineRes, SEXP coarseRes,SEXP rsquaredthreshold, SEXP cores){
	
	//get image data
	Rcpp::NumericVector tmpArrayLandsatM(fineM);
	Rcpp::IntegerVector arrayDims = tmpArrayLandsatM.attr("dim");
	arma::cube armaLandsatM(tmpArrayLandsatM.begin(), arrayDims[0], arrayDims[1], arrayDims[2], false);
	Rcpp::NumericVector tmpArrayLandsatN(fineN);
	arma::cube armaLandsatN(tmpArrayLandsatN.begin(), arrayDims[0], arrayDims[1], arrayDims[2], false);
	Rcpp::NumericVector tmpArrayModisM(coarseM);
	arma::cube armaModisM(tmpArrayModisM.begin(), arrayDims[0], arrayDims[1], arrayDims[2], false);
	Rcpp::NumericVector tmpArrayModisP(coarseP);
	arma::cube armaModisP(tmpArrayModisP.begin(), arrayDims[0], arrayDims[1], arrayDims[2], false);
	Rcpp::NumericVector tmpArrayModisN(coarseN);
	arma::cube armaModisN(tmpArrayModisN.begin(), arrayDims[0], arrayDims[1], arrayDims[2], false);

	//get other parameters
	const unsigned int cntBands = armaLandsatM.n_slices;
	const unsigned int windowWidth = Rcpp::as<int>(winWidth);
	const unsigned int estimatedClasses = Rcpp::as<int>(estClasses); 
	const double ratioCoarseToFine = Rcpp::as<double>(coarseRes) / Rcpp::as<double>(fineRes);
	const double correlationCoefficientThreshold = Rcpp::as<int>(rsquaredthreshold); 
	const unsigned int xExtend = armaModisP.n_cols;
	const unsigned int yExtend = armaModisP.n_rows;
	const unsigned int tmpCores = Rcpp::as<int>(cores);

	//check number of cores
	if(tmpCores <= 0){
		__countCores = std::max(std::thread::hardware_concurrency(), (unsigned int)1);
	}
	else{
		__countCores = tmpCores;
	}

	//copy data from rcpp to eigen
	Image landsatM(cntBands, Band(yExtend, xExtend)), landsatN(cntBands, Band(yExtend, xExtend)), modisM(cntBands, Band(yExtend, xExtend)), modisN(cntBands, Band(yExtend, xExtend)), modisP(cntBands, Band(yExtend, xExtend));
	
	for(unsigned int i = 0; i < cntBands; ++i){
		for(unsigned int j = 0; j < yExtend; ++j){
			for(unsigned int k = 0; k < xExtend; ++k){
				landsatM[i](j, k) = armaLandsatM.slice(i)(j, k);
				landsatN[i](j, k) = armaLandsatN.slice(i)(j, k);
				modisM[i](j, k) = armaModisM.slice(i)(j, k);
				modisP[i](j, k) = armaModisP.slice(i)(j, k);
				modisN[i](j, k) = armaModisN.slice(i)(j, k);
			}
		}
	}
	
	//calculate result and remove border
	const auto &resImage = removeZeroBorder(programLoop(landsatM, landsatN, modisM, modisN, modisP, windowWidth, estimatedClasses, ratioCoarseToFine, correlationCoefficientThreshold),(windowWidth-1)/2);
	
	
	
	//copy data to rcpp
	const int resXExtend = resImage[0].cols();
	const int resYExtend = resImage[0].rows();

	Rcpp::NumericVector armaLandsatP(resYExtend * resXExtend * cntBands);
	
	for(unsigned int i = 0; i < cntBands; ++i){
		for(unsigned int j = 0; j < resYExtend; ++j){
			for(unsigned int k = 0; k < resXExtend; ++k){
				armaLandsatP[j + k * resYExtend + i * resYExtend * resXExtend] = resImage[i](j,k);
			}
		}
	}	
	
	return (Rcpp::wrap(armaLandsatP));
	
}



